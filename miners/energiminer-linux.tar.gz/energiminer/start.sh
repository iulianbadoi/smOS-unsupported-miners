#!/bin/bash

./energiminer --coinbase-addr "YourWalletAddress" --opencl --opencl-platform 0 --opencl-devices 0 "http://UniqueUserName:SecurePassword@127.0.0.1:9796"
